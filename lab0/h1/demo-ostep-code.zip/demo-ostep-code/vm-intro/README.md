# Overview

Code from OSTEP chapter [The Abstraction: Address Spaces](http://pages.cs.wisc.edu/~remzi/OSTEP/vm-intro.pdf).

To compile, just type:
```
prompt> make
```

See the highly primitive `Makefile` for details.

Then, run it:

```
prompt> ./virtual-addresses
```

